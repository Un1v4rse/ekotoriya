#!/usr/bin/env python3
"""
База клиентов, заявок и лайков на БД (AR-1, CL-1…CL-3).

Публичные функции и формат возвращаемых dict сохранены (app.py и шаблоны
не меняются):
    add_customer(name, phone, email) -> customer dict
    add_order(name, phone, email, product_id, product_name, price) -> order dict
    get_customers() / get_orders() -> list of dict
    update_order_status(order_id, status) -> order dict | None
    add_like(product_id, product_name)
    get_like_counts() -> {product_id: count}
    get_popular_products(products, limit, like_weight)

Дедупликация клиентов — по нормализованному телефону (CL-2; email —
дополнительный признак при совпадении). Лайки хранятся в events (RS-1).

Все функции требуют активного Flask app-контекста (запросы — всегда есть).
"""
from datetime import datetime, timedelta, timezone

from db import db
from models import Customer, CustomerAuth, Event, Order, Recommendation


def utcnow():
    return datetime.now(timezone.utc)


def normalize_phone(phone):
    """Нормализация телефона в канонический вид +7XXXXXXXXXX (CL-2).

    «8 900 …», «+7 900 …» и «900 …» (10 цифр) приводятся к одному ключу —
    иначе один и тот же клиент дублировался бы в базе. Прочие номера —
    без изменений (цифры с сохранением ведущего +).
    """
    digits = ''.join(c for c in str(phone or '') if c.isdigit())
    if len(digits) == 11 and digits[0] in ('7', '8'):
        return '+7' + digits[1:]
    if len(digits) == 10:
        return '+7' + digits
    plus = '+' if str(phone or '').strip().startswith('+') else ''
    return plus + digits


def _coerce_product_id(pid):
    """Как раньше _norm_product_id: int, если строка из цифр, иначе str."""
    if pid is None:
        return ''
    if isinstance(pid, int):
        return str(pid)
    s = str(pid)
    return s


def _display_product_id(pid):
    s = str(pid or '')
    return int(s) if s.isdigit() else s


def _touch(customer):
    customer.updated_at = utcnow()
    customer.last_activity_at = utcnow()


def add_customer(name, phone, email='', consent_pd=False):
    """Добавить или обновить клиента по телефону (CL-1, CL-2)."""
    phone_norm = normalize_phone(phone)
    customer = db.session.query(Customer).filter_by(phone=phone_norm).first()
    if customer is None and email:
        # Дополнительная дедупликация по email (CL-2)
        customer = db.session.query(Customer).filter_by(email=email).first()
        if customer is not None and customer.phone and customer.phone != phone_norm:
            customer = None  # телефон — главный ключ; email совпал случайно
    now = utcnow()
    if customer is None:
        customer = Customer(phone=phone_norm, created_at=now)
        db.session.add(customer)
    customer.name = name or customer.name or ''
    customer.email = email or customer.email or ''
    if consent_pd:
        customer.consent_pd = True
        customer.consent_at = now
    _touch(customer)
    db.session.commit()
    return customer.to_dict()


def get_customer_by_phone(phone):
    customer = db.session.query(Customer).filter_by(phone=normalize_phone(phone)).first()
    return customer.to_dict() if customer else None


def register_client(phone, password, name='', email=''):
    """Регистрация клиента по телефону+паролю (LC-1).

    Дедупликация по нормализованному телефону. Пароль — только хэш Werkzeug.
    Если клиент с таким телефоном уже зарегистрирован (есть password_hash) —
    ошибка. Без SMS и верификации номера (по ТЗ).
    """
    from werkzeug.security import generate_password_hash
    phone_norm = normalize_phone(phone)
    if not phone_norm:
        return None, 'Телефон обязателен'
    if not password or len(password) < 6:
        return None, 'Пароль должен быть не короче 6 символов'
    existing = db.session.query(Customer).filter_by(phone=phone_norm).first()
    if existing is not None and existing.password_hash:
        return None, 'Этот телефон уже зарегистрирован. Войдите.'
    customer = add_customer(name, phone_norm, email)
    row = db.session.get(Customer, customer['id'])
    row.password_hash = generate_password_hash(password)
    db.session.commit()
    return row.to_dict(), None


def login_client(phone, password):
    """Вход клиента: проверка хэша пароля (LC-1, LC-2)."""
    from werkzeug.security import check_password_hash
    phone_norm = normalize_phone(phone)
    row = db.session.query(Customer).filter_by(phone=phone_norm).first()
    if row is None or not row.password_hash:
        return None
    if not check_password_hash(row.password_hash, password or ''):
        return None
    _touch(row)
    db.session.commit()
    return row.to_dict()


def update_customer_profile(customer_id, name=None, email=None, phone=None):
    """Обновление контактов клиента из ЛК (LC-3, этап 7.1).

    Телефон — логин, меняется с проверкой уникальности нормализованного
    значения; при конфликте возвращает (None, 'ошибка')."""
    row = db.session.get(Customer, int(customer_id))
    if row is None:
        return None
    if phone is not None:
        phone_norm = normalize_phone(phone)
        if not phone_norm:
            return None, 'Некорректный телефон'
        conflict = db.session.query(Customer).filter(
            Customer.phone == phone_norm, Customer.id != row.id).first()
        if conflict is not None:
            return None, 'Этот телефон уже привязан к другому аккаунту'
        row.phone = phone_norm
    if name is not None:
        row.name = name.strip()
    if email is not None:
        row.email = email.strip()
    _touch(row)
    db.session.commit()
    return row.to_dict()


def change_client_password(customer_id, current_password, new_password):
    """Смена пароля из ЛК (этап 7.1): проверяем текущий, валидируем новый."""
    from werkzeug.security import check_password_hash, generate_password_hash
    row = db.session.get(Customer, int(customer_id))
    if row is None or not row.password_hash:
        return None, 'Клиент не найден'
    if not check_password_hash(row.password_hash, current_password or ''):
        return None, 'Текущий пароль неверный'
    if not new_password or len(new_password) < 6:
        return None, 'Новый пароль должен быть не короче 6 символов'
    row.password_hash = generate_password_hash(new_password)
    _touch(row)
    db.session.commit()
    return row.to_dict(), None


def add_order(name, phone, email, product_id, product_name, price, qty=1,
              source='oneclick', status='new', customer_id=None, consent_pd=False):
    """Новая заявка + гарантированное создание клиента (CL-1)."""
    if customer_id is None:
        customer = add_customer(name, phone, email, consent_pd=consent_pd)
        customer_id = customer['id']
    else:
        existing = db.session.get(Customer, customer_id)
        if existing is None:
            customer = add_customer(name, phone, email, consent_pd=consent_pd)
            customer_id = customer['id']
        elif consent_pd and not existing.consent_pd:
            existing.consent_pd = True
            existing.consent_at = utcnow()
    order = Order(
        customer_id=customer_id,
        name=name or '',
        phone=normalize_phone(phone),
        email=email or '',
        product_id=_coerce_product_id(product_id),
        product_name=product_name or '',
        price=int(price or 0),
        qty=max(1, int(qty or 1)),
        status=status,
        source=source,
    )
    db.session.add(order)
    customer = db.session.get(Customer, customer_id)
    if customer is not None:
        _touch(customer)
    db.session.commit()
    d = order.to_dict()
    d['product_id'] = _display_product_id(d['product_id'])
    return d


def get_customers():
    return [c.to_dict() for c in db.session.query(Customer).order_by(Customer.id).all()]


def get_customer_orders(customer_id):
    orders = (db.session.query(Order)
              .filter_by(customer_id=customer_id)
              .order_by(Order.id.desc()).all())
    result = []
    for o in orders:
        d = o.to_dict()
        d['product_id'] = _display_product_id(d['product_id'])
        result.append(d)
    return result


def get_orders():
    result = []
    for o in db.session.query(Order).order_by(Order.id).all():
        d = o.to_dict()
        d['product_id'] = _display_product_id(d['product_id'])
        result.append(d)
    return result


def update_order_status(order_id, status):
    order = db.session.get(Order, int(order_id))
    if order is None:
        return None
    order.status = status
    order.updated_at = utcnow()
    db.session.commit()
    d = order.to_dict()
    d['product_id'] = _display_product_id(d['product_id'])
    return d


def add_event(etype, product_id=None, product_name='', customer_id=None,
              session_id='', query='', payload=''):
    """Записать событие (RS-1): view|like|order|favorite|search."""
    db.session.add(Event(
        type=etype,
        customer_id=customer_id,
        session_id=session_id or '',
        product_id=_coerce_product_id(product_id),
        product_name=product_name or '',
        query=query or '',
        payload=payload or '',
    ))
    db.session.commit()


def add_like(product_id, product_name='', customer_id=None, session_id='',
             snapshot=None):
    """Публичный лайк товара (как раньше, плюс событие).

    Дедупликация: повторный лайк того же товара от того же посетителя
    (по аккаунту ИЛИ по сессии — что известно) не создаёт новое событие,
    иначе публичный счётчик накручивался бы неограниченно одним пользователем.
    Возвращает True, если лайк записан, False — если уже был.
    snapshot: dict с ценой/фото/ссылкой товара (JSON в events.payload).
    """
    import json as _json
    pid = _coerce_product_id(product_id)
    if customer_id or session_id:
        q = db.session.query(Event).filter_by(type='like', product_id=pid)
        cond = []
        if customer_id:
            cond.append(Event.customer_id == customer_id)
        if session_id:
            cond.append(Event.session_id == session_id)
        if q.filter(db.or_(*cond)).first() is not None:
            return False  # уже лайкнуто этим посетителем
    payload = ''
    if snapshot:
        try:
            payload = _json.dumps(snapshot, ensure_ascii=False)[:4000]
        except (TypeError, ValueError):
            payload = ''
    add_event('like', product_id=pid, product_name=product_name,
              customer_id=customer_id, session_id=session_id, payload=payload)
    return True


def remove_like(product_id, customer_id=None, session_id=''):
    """Снять лайк посетителя (toggle). Удаляет события like товара, у которых
    совпадает аккаунт или сессия. Возвращает число удалённых событий."""
    pid = _coerce_product_id(product_id)
    q = db.session.query(Event).filter_by(type='like', product_id=pid)
    cond = []
    if customer_id:
        cond.append(Event.customer_id == customer_id)
    if session_id:
        cond.append(Event.session_id == session_id)
    if not cond:
        return 0
    rows = q.filter(db.or_(*cond)).all()
    for e in rows:
        db.session.delete(e)
    db.session.commit()
    return len(rows)


def is_liked(product_id, customer_id=None, session_id=''):
    """Лайкнул ли текущий посетитель товар (по аккаунту или сессии)."""
    pid = _coerce_product_id(product_id)
    q = db.session.query(Event).filter_by(type='like', product_id=pid)
    cond = []
    if customer_id:
        cond.append(Event.customer_id == customer_id)
    if session_id:
        cond.append(Event.session_id == session_id)
    if not cond:
        return False
    return q.filter(db.or_(*cond)).first() is not None


def _int_key(pid):
    s = str(pid or '')
    return int(s) if s.isdigit() else s


def bind_session_likes(customer_id, session_id=''):
    """При входе/регистрации переписываем анонимные лайки сессии на клиента (LC-3).

    Иначе товары, лайкнутые до входа, не попадали в избранное /personal/favorite/.
    """
    if not customer_id or not session_id:
        return 0
    rows = (db.session.query(Event)
            .filter_by(type='like', session_id=session_id, customer_id=None)
            .all())
    for e in rows:
        e.customer_id = customer_id
    if rows:
        db.session.commit()
    return len(rows)


def get_like_counts():
    """{product_id: count} — ключи int, где возможно (совместимость)."""
    rows = (db.session.query(Event.product_id, db.func.count(Event.id))
            .filter_by(type='like')
            .group_by(Event.product_id).all())
    return {_int_key(pid): count for pid, count in rows if pid}


def get_customer_likes(customer_id):
    """Лайкнутые товары клиента (LC-3), с снапшотом из события если есть."""
    rows = (db.session.query(Event)
            .filter_by(type='like', customer_id=customer_id)
            .order_by(Event.id.desc()).all())
    return _likes_rows_to_dicts(rows)


def get_visitor_likes(customer_id=None, session_id=''):
    """Лайкнутые товары текущего посетителя: по аккаунту, иначе по анонимной
    сессии (та же логика привязки, что в /api/like). Для разметки уже
    лайкнутых кнопок и счётчика в шапке при серверном рендере."""
    q = (db.session.query(Event)
         .filter_by(type='like')
         .order_by(Event.id.desc()))
    if customer_id:
        q = q.filter_by(customer_id=customer_id)
    else:
        q = q.filter_by(customer_id=None, session_id=session_id or '')
    return _likes_rows_to_dicts(q.all())


def _likes_rows_to_dicts(rows):
    """Дедуп по product_id + разбор JSON-снапшота (events.payload)."""
    import json as _json
    seen, result = set(), []
    for e in rows:
        pid = _int_key(e.product_id)
        if pid in seen:
            continue
        seen.add(pid)
        snap = {}
        if e.payload:
            try:
                snap = _json.loads(e.payload) or {}
            except (TypeError, ValueError):
                snap = {}
        result.append({'product_id': pid, 'product_name': e.product_name or '',
                       'snapshot': snap})
    return result


def _product_key(p):
    """Универсальный id товара из dict (WB nm_id или Ozon offer_id)."""
    return p.get('nm_id') or p.get('offer_id') or p.get('id') or 0


def get_popular_products(products, limit=8, like_weight=1):
    """Топ товаров по заказам + лайкам из базы клиентов (RS-2, fallback RS-5)."""
    order_counts = {}
    for o in db.session.query(Order.product_id).all():
        pid = _int_key(o.product_id)
        if pid != '':
            order_counts[pid] = order_counts.get(pid, 0) + 1
    like_counts = get_like_counts()

    scored = []
    for p in products:
        pid = _product_key(p)
        if not pid:
            continue
        pid_key = _int_key(pid)
        orders_n = order_counts.get(pid_key, 0)
        likes_n = like_counts.get(pid_key, 0)
        score = orders_n + likes_n * like_weight
        if score > 0:
            scored.append({'product': p, 'score': score,
                           'orders': orders_n, 'likes': likes_n})

    scored.sort(key=lambda x: x['score'], reverse=True)
    return scored[:limit]


def get_customer_stats(customer_id):
    """Сумма покупок и последняя активность для профиля (CL-3)."""
    orders = db.session.query(Order).filter_by(customer_id=customer_id).all()
    total = sum(o.price * o.qty for o in orders)
    customer = db.session.get(Customer, customer_id)
    return {
        'orders_count': len(orders),
        'total_spent': total,
        'last_activity_at': customer.last_activity_at.isoformat() if customer and customer.last_activity_at else '',
    }


def delete_customer(customer_id):
    """Полное удаление клиента по запросу (152-ФЗ, CL-6): каскадно заявки,
    события, сессии и рекомендации. Возвращает True, если клиент был найден."""
    customer = db.session.get(Customer, int(customer_id))
    if customer is None:
        return False
    cid = customer.id
    db.session.query(Order).filter_by(customer_id=cid).delete()
    db.session.query(Event).filter_by(customer_id=cid).delete()
    db.session.query(CustomerAuth).filter_by(customer_id=cid).delete()
    db.session.query(Recommendation).filter_by(customer_id=cid).delete()
    db.session.delete(customer)
    db.session.commit()
    return True


def _naive(dt):
    """SQLite возвращает наивные datetime — приводим к наивному UTC для сравнений."""
    if dt is None:
        return None
    if dt.tzinfo is not None:
        return dt.replace(tzinfo=None)
    return dt


def _customers_by_ids(ids):
    if not ids:
        return []
    rows = (db.session.query(Customer)
            .filter(Customer.id.in_(list(ids)))
            .order_by(Customer.id).all())
    return [c.to_dict() for c in rows]


def compute_segments(products, days=30, min_orders=2):
    """Сегменты клиентов (CL-5). Правила:
    - «покупал категорию X» — клиенты с заявками на товары категории X;
    - «N заявок за период» — min_orders+ заявок за последние days дней;
    - «не активен 30 дней» — нет заявок и событий за последние days дней.
    Возвращает list of dict: key, title, count, customers (полные dict клиентов).
    """
    cat_by_pid = {}
    for p in products or []:
        pid = str(p.get('nm_id') or p.get('offer_id') or '')
        cat = (p.get('category') or '').strip()
        if pid and cat:
            cat_by_pid[pid] = cat

    now = _naive(datetime.now(timezone.utc))
    window_start = now - timedelta(days=days)

    orders = db.session.query(Order).all()
    events = db.session.query(Event).all()

    by_category = {}
    counts_window = {}
    active_ids = set()
    for o in orders:
        created = _naive(o.created_at)
        if created and created >= window_start:
            counts_window[o.customer_id] = counts_window.get(o.customer_id, 0) + 1
            active_ids.add(o.customer_id)
        cat = cat_by_pid.get(str(o.product_id))
        if cat:
            by_category.setdefault(cat, set()).add(o.customer_id)
    for e in events:
        created = _naive(e.created_at)
        if created and created >= window_start:
            active_ids.add(e.customer_id)

    segments = []
    for cat in sorted(by_category):
        ids = by_category[cat]
        segments.append({
            'key': f'category:{cat}',
            'title': f'Покупали категорию «{cat}»',
            'count': len(ids),
            'customers': _customers_by_ids(ids),
        })

    freq_ids = {cid for cid, n in counts_window.items() if n >= min_orders}
    segments.append({
        'key': f'orders>={min_orders}:{days}d',
        'title': f'{min_orders}+ заявок за {days} дней',
        'count': len(freq_ids),
        'customers': _customers_by_ids(freq_ids),
    })

    all_ids = {row[0] for row in db.session.query(Customer.id).all()}
    inactive_ids = all_ids - active_ids
    segments.append({
        'key': f'inactive:{days}d',
        'title': f'Не активны {days} дней',
        'count': len(inactive_ids),
        'customers': _customers_by_ids(inactive_ids),
    })
    return segments
